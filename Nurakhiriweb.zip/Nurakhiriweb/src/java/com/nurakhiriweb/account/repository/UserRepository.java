package com.nurakhiriweb.account.repository;

import com.nurakhiriweb.account.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);

    public void save(User user);
}